<?php

session_start();

include('../php/header.php');
include('../php/nav.php');
include('../php/bdd.php');

$date= date('Y-m-d');

$req = $bdd ->prepare(' UPDATE commentaires set libelle = ?, auteur_com = ?,date_com = ? where id_commentaire = ? ') ;

$free = $req ->execute(array($_POST['com'],$_POST['auteur'],$date,$_SESSION['id']));

if ($free) {
    echo '<script> alert("donnees modifiees")</script>';
} else {
    echo '<script> alert("donnees non modifiees")</script>' ;
}


?>