<?php

session_start();

include('../php/header.php');
include('../php/nav.php');
include('../php/bdd.php');

 

$req = $bdd ->prepare(' UPDATE inscription_employeur set nom = ?,prenom = ?,email = ?,contact = ?,profession = ?,lieu_habitation = ? where employeur_id = ? ') ;

$free = $req ->execute(array($_POST['name'],$_POST['lastname'],$_POST['email'],$_POST['contact'],$_POST['profession'],$_POST['lieu'],$_SESSION['id']));

if ($free) {
    echo '<script> alert("donnees modifiees")</script>';
} else {
    echo '<script> alert("donnees non modifiees")</script>' ;
}


?>