<?php

session_start();

include('../php/header.php');
include('../php/nav.php');
include('../php/bdd.php');

 

$req = $bdd ->prepare(' UPDATE incription_candidat set nom = ?,prenom = ?,age = ?,email = ?,contact = ?,niveau_etude = ?,description = ?,genre = ? where candidat_id = ? ') ;

$free = $req ->execute(array($_POST['name'],$_POST['lastname'],$_POST['age'],$_POST['email'],$_POST['contact'],$_POST['niveau'],$_POST['description'],$_POST['genre'],$_SESSION['id']));

if ($free) {
    echo '<script> alert("donnees modifiees")</script>';
} else {
    echo '<script> alert("donnees non modifiees")</script>' ;
}


?>