<?php
session_start();
include('php/bdd.php');
    if( !empty($_POST['nom']) && !empty($_POST['pass']))//je verifie que le formulaire à été soumis
    {

      
        $pseudo =$_POST['nom'];   
        $pass = sha1($_POST['pass']);

        //Condition de test
                 $result= $bdd->prepare('SELECT * FROM admin WHERE hash = ? and pseudo = ? ');
        $verif = $result->execute(array($pass,$pseudo ));
        
         $val = $result->fetch();


      $_SESSION['nom'] = $val['pseudo'] ;

      

        if ($verif) 
        {
           echo '<script type="text/javascript"> alert("bienvenue") </script>'.header("location:dashboard/dashboard.php") ;
        } else {
           echo 'svp reesayer' ;
        }
        
    }
    else 
    {
    echo 'desole recommencer'.header("location:login.php") ;
    }