<?php
session_start();
include('../php/header.php');
include('../php/nav.php');
?>
<!--main content start-->
<section id="main-content">
      <section class="wrapper">
        <h3><i class="fa fa-angle-right"></i> Nouvelle Demande</h3>
      </section>
      <div class="row mt">
          <div class="col-md-12">
            <div class="content-panel">
              <table class="table table-striped table-advance table-hover">
                <hr>
                <thead>
                  <tr>
                    <th><i class="fa fa-bullhorn"></i> Nom</th>
                    <th class="hidden-phone"><i class="fa fa-question-circle"></i> Prenom</th>
                    <th><i class="fa fa-bookmark"></i> Contact</th>
                    <th><i class=" fa fa-edit"></i> Domicile</th>
                    <th><i class="fa fa-bookmark"></i> Salaire</th>
                  </tr>
                </thead>
                <?php
                include('../php/bdd.php');
                $date= date('Y-m-d');

                 //condition de teste
                  $solut=$bdd->prepare("SELECT candidat.Nom, candidat.Prenom, candidat.Contact, candidat.Domicile, candidat.Estimationsalariale 
                                        FROM demande 
                                        INNER JOIN candidat ON demande.CandidatID=candidat.CandidatID");
                  $solut->execute();
                ?>
                <?php
                  if($solut)
                  {
                    while($row=$solut->fetch())
                    {
                      if($row['Nom'])
                      {
                        echo "<tr>";
                        echo "<td>".$row['Nom']."</td>";
                        echo "<td>".$row['Prenom']."</td>";
                        echo "<td>".$row['Contact']."</td>";
                        echo "<td>".$row['Domicile']."</td>";
                        echo "<td>".$row['Estimationsalariale']." Fcfa</td>";
                      }
                    }
                    
                  }
                ?>
                 
                 </tbody>
              </table>
            </div>
            <!-- /content-panel -->
          </div>
          <!-- /col-md-12 -->
        </div>
        <!-- /row -->
        <!-- /row -->
      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
  <?php
  include('../php/footer.php');
  ?>  