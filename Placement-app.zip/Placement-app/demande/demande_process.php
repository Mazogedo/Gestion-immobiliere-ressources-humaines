<?php
session_start();
include('../php/bdd.php');

      if(($_GET['candidatid']))//je verifie que le formulaire à été soumis
    {
        $employeurid = $_SESSION['userid'];  
        $candidatid =$_GET['candidatid'];
        $date= date('Y-m-d');
       // $Estimationsalariale=$_GET['salaire'];
        //Condition de teste
         
         echo "EMPLOYEUR  ".$_SESSION['userid']."</br>";
        echo "DATE  ".$date."</br>";
        echo "CandidatID ".$candidatid."</br>";
        
        // preparation de la requete
        $result= $bdd->prepare("INSERT INTO demande(Datedemande,EmployeurID,CandidatID) VALUES (:datedemande,:employeurid,:candidatid)");
            // excecution de la requete
        $result->execute(array(
            'datedemande'=>$date,
            'employeurid'=>$employeurid,
            'candidatid'=>$candidatid,
        ));
       
           if($result)//je verifie que l'insertion est reussi
            {
                $_SESSION['flash']="DEMANDE PRISE EN COMPTE";
                echo "<script type='text/javascript'>location.href = '../recherche/recherche.php';</script>";
            } 
            else
            {
                $_SESSION['flash']="ERREUR LORS DE LA PRISE EN COMPTE DE LA DEMANDE";
                echo "<script type='text/javascript'>location.href = '../demande/demande.php';</script>";
            }
        
        $result->closecursor();
    }    
  