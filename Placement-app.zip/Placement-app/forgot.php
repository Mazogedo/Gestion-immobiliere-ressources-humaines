<?php
include('php/bdd.php');
    if( !empty($_POST['email']) && !empty($_POST['date']))//je verifie que le formulaire à été soumis
    {

        $email =$_POST['email'];   
        $date = $_POST['date'];
        //Condition de teste
                 $result = $bdd->prepare('SELECT * FROM admin WHERE email = ? and birthday = ? ');
        $verif = $result->execute(array($email,$date));

        $ok = $result->rowCount();

        $free = $result ->fetch();


        if ($ok)
        {
           echo '<marquee style="font-size:30px;">'.$free['pseudo'].'  voici votre mot de passe :  '.'<h2 style="color:red;">' .$free['pass'].' </h2> '.'</marquee>' ;
        } else {
           echo 'svp reesayer'.header("location:mot_passe.php");
        }   
        
    }
    else 
    {
    echo 'desole recommencer'.header("location:login.php") ;
    }



?>
<body style="background-image:url('img/login-bg.jpg');">
<a style="font-size:30px;color:green;" href="login.php"><--retour</a>
</body>