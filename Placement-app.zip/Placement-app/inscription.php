<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>PlacementApp</title>
<!
  <!-- Favicons -->
  <link href="img/favicon.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
  <link href="lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet">

</head>

  <div id="login-page">
    <div class="container">
      <form action="verif_inscription.php" method="post" class="form-login">
        <h2 class="form-login-heading"> INSCRIPTION </h2>
        <div class="login-wrap">
        
                <div>
                    <input type="text" name="name" placeholder="votre pseudo/nom " size="36" required>
                </div>
                <div>
                    <input style="width:99%;" type="date" name="date" size="70" required>
                </div>
                <div>
                    <input type="email" name="email" placeholder="votre email" size="36" required>
                </div>
                <div>
                    <input type="password" name="pass" placeholder="mot de passe" size="36" required> 
                </div>
                <div>
                    <button  style="position:relative;left:30%;top:10px; "> Soumettre </button>
                </div>


                   




       
        </div>
      
        <!-- Modal -->
       
        <!-- modal -->
      </form>
    </div>
  </div>
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.min.js"></script>
  <!--BACKSTRETCH-->
  <!-- You can use an image of whatever size. This script will stretch to fit in any screen size.-->
  <script type="text/javascript" src="lib/jquery.backstretch.min.js"></script>
  <script>
    $.backstretch("img/login-bg.jpg", {
      speed: 500
    });
  </script>
</body>

</html>