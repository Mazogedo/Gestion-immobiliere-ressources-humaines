<?php
session_start();
include('../php/header.php');
include('../php/nav.php');

$result=0;
?>
<!--main content start-->
<section id="main-content">
      <section class="wrapper">
        <?php
         echo"<center>";
 if (isset($_SESSION['flash'])) 
 {
   echo"<div class='alert alert-success'><strong>" . $_SESSION['flash']. "</strong></div>";
   unset($_SESSION['flash']);
   
 }

 echo"</center>";
        ?>
        <h3><i class="fa fa-angle-right"></i> Recherche</h3>
       <!-- row -->
       <!-- INLINE FORM ELELEMNTS -->
       <div class="row mt">
          <div class="col-lg-12">
            <div class="form-panel">
              <h4 class="mb"><i class="fa fa-angle-right"></i> Inline Form</h4>
              <form action="" method="post" class="form-inline">
                <div class="form-group">
                  <label class="sr-only" for="exampleInputEmail2">Niveau d'Etude</label>
                  <input type="text" class="form-control" name="niveau" id="exampleInputEmail2" placeholder="Niveau d'étude">
                </div>
                <div class="form-group">
                  <label class="sr-only" for="exampleInputPassword2">Compétence</label>
                  <input type="text" class="form-control" name="competence" id="exampleInputPassword2" placeholder="Compétence">
                </div>
                <div class="form-group">
                  <label class="sr-only"  for="exampleInputPassword2">Sexe</label>
                  <select class="form-control" name="sexe">
                    <option value="Homme">Masculin</option>
                    <option value="Femme">Feminin</option>
                  </select>
                </div>
                <div class="form-group">
                  <label class="sr-only" for="exampleInputPassword2">Estimation salariale</label>
                  <input type="number" class="form-control" name="salaire" id="exampleInputPassword2" placeholder="Estimation salariale">
                </div>
                <button type="submit" class="btn btn-theme" name="recherche">Recherche</button>
              </form>
            </div>
            <!-- /form-panel -->
          </div>
          <!-- /col-lg-12 -->
       <div class="row mt">
          <div class="col-md-12">
            <div class="content-panel">
              <table class="table table-striped table-advance table-hover">
                <hr>
                <thead>
                  <tr>
                    <th><i class="fa fa-bullhorn"></i> Nom</th>
                    <th class="hidden-phone"><i class="fa fa-question-circle"></i> Prenom</th>
                    <th><i class="fa fa-bookmark"></i> Contact</th>
                    <th><i class=" fa fa-edit"></i> Domicile</th>
                    <th><i class="fa fa-bookmark"></i> Niveau</th>
                    <th><i class=" fa fa-edit"></i> Compétence</th>
                    <th><i class="fa fa-bookmark"></i> Salaire</th>
                    <th><i class=" fa fa-edit"></i> Matrimonial</th>
                    <th><i class=" fa fa-edit"></i> Action </th>
                    <th></th>
                  </tr>
                </thead>
                <?php
                  include('../php/bdd.php');
                    if (isset($_POST['recherche'])) 
                    {

                      if(($_POST['salaire'])&&($_POST['competence'])&&($_POST['niveau']))//je verifie que le formulaire à été soumis
                  {
                     
                      //Condition de teste
                      $result= $bdd->prepare("SELECT * FROM Candidat WHERE NiveauEtude=:niveau & Competence=:competence & Sexe=:sexe &
                                              EstimationSalariale<=:salaire");
                      $result->execute(array(
                          'niveau'=>$_POST['niveau'],
                          'competence'=>$_POST['competence'],
                          'salaire'=>$_POST['salaire'],
                          'sexe'=>$_POST['sexe'],
                      ));
                  }
                      
                    }

                  
                ?>
                <tbody>
                <?php 
                          if($result)
                          {  
                            while($roti=$result->fetch()) 
                            {
                              if($roti['CandidatID'])//je verifie que l'insertion est reussi
                              {
                              echo "<tr>";
                              echo "<td>".$roti['Nom']."</td>";
                              echo "<td>".$roti['Prenom']."</td>";
                              echo "<td>".$roti['Contact']."</td>";
                              echo "<td>".$roti['Domicile']."</td>";
                              echo "<td>".$roti['NiveauEtude']."</td>";
                              echo "<td>".$roti['Competence']."</td>";
                              echo "<td>".$roti['Estimationsalariale']."</td>";
                              echo "<td>".$roti['Statutmatrimonial']."</td>";
                              echo "<td><button type='button' class='btn btn-round btn-primary'>" ;
                              ?>
                              <a href="../demande/demande_process.php?candidatid=<?php echo $roti['CandidatID']?>"> Accepte</a></button></td>
                              <?php
                              }
                              else
                            {
                              echo "<td> Aucune resultat trouvé</td>";
                            }
                              
                          ?>

                            <?php
                              echo "</tr>";                              
                              
                            }
                        
                          }
                        ?> 
                 
                </tbody>
              </table>
            </div>
            <!-- /content-panel -->
          </div>
          <!-- /col-md-12 -->
        </div>
        <!-- /row -->
        <!-- /row -->
      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
  <?php
  include('../php/footer.php');
  ?>  