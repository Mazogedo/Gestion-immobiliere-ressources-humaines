<?php

include('../php/header.php');
include('../php/nav.php');


?>

?>
<!--main content start-->
<section id="main-content">
      <section class="wrapper">
 
        <h3><i class="fa fa-angle-right"></i>PAGE D'ADMINISTRATION</h3>
       <!-- row -->
       <!-- INLINE FORM ELELEMNTS -->
       <div class="row mt">
          <div class="col-lg-10">
            
            <!-- /form-panel -->
          </div>
          
        <!-- /row -->
        <!-- /row -->
      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->