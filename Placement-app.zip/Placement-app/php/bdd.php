<?php
//je me connecte à la base de donnée
try
{
$bdd = new PDO('mysql:host=localhost;dbname=boss', 'root', '');
}
catch (Exception $e)
{
die('Erreur : ' . $e->getMessage());
}