<body>
<?php

session_start();
$_SESSION['nom'];
?>
  <section id="container">
    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
    <!--header start-->
    <header class="header black-bg">
      <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
      </div>
      <!--logo start-->
      <a href="dashboard.php" class="logo"><img style="width:100px;height:40px;" src="../img/carre.jpg"></a>
      <!--logo end-->
      <div class="nav notify-row" id="top_menu">
        <!--  notification end -->
      </div>
      <div class="top-menu">
        <ul class="nav pull-right top-menu">
          <li><a class="logout" href="../logout.php" onclick="return confirm('Voulez-vous vraiment vous déconnectez ?')" >Deconnexion</a></li>
        </ul>
      </div>
    </header>
    <!--header end-->
    <!--sidebar start-->
<?php
include('../php/bdd.php');
//nombre de table admin
$req = $bdd ->prepare('SELECT COUNT(id) as nbre from admin ') ;
$req ->execute();
$free = $req ->fetch();

//nombre de table personnel
$requ = $bdd ->prepare('SELECT COUNT(perso_id) as nbre from personnel ') ;
$requ ->execute();
$freem = $requ ->fetch();

//nombre de table immobilier
$reque = $bdd ->prepare('SELECT COUNT(immobilier_id) as nbre from immobilier ') ;
$reque ->execute();
$freema = $reque ->fetch();

//nombre de table candidat
$requet = $bdd ->prepare('SELECT COUNT(candidat_id) as nbre from  incription_candidat ') ;
$requet ->execute();
$freeman = $requet ->fetch();

//nombre de table employeur
$requete = $bdd ->prepare('SELECT COUNT(employeur_id) as nbre from inscription_employeur ') ;
$requete ->execute();
$freemane = $requete ->fetch();

//nombre de table commentaire
$requetes = $bdd ->prepare('SELECT COUNT(id_commentaire) as nbre from commentaires ') ;
$requetes ->execute();
$freemanes = $requetes ->fetch();



echo $free['nbre'];
echo $freem['nbre'];
echo $freema['nbre'];
echo $freeman['nbre'];
echo $freemane['nbre'];
echo $freemanes['nbre'];





?>

    <aside>
      <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
          <p class="centered"><a href="profile.html"><img src="../img/ui-sam.jpg" class="img-circle" width="80"></a></p>
          <h5 class="centered"> <?php echo $_SESSION['nom'] ;  ?> </h5>
          <li>
             <a href="../candidat/candidat.php">
              <i class="fa fa-dashboard"></i>
              <span>CANDIDAT</span>
              <span class="label label-theme pull-right mail-info"> <?= $freeman['nbre'] ; ?> </span>
              </a>
          </li>
          <li>
             <a href="../employeur/employeur.php">
              <i class="fa fa-arrows-alt"></i>
              <span>EMPLOYEUR</span>
              <span class="label label-theme pull-right mail-info"> <?= $freemane['nbre']; ?> </span>
              </a>
          </li>
           <li>
            <a href="../admin/admin.php">
              <i class="fa fa-envelope"></i>
              <span>ADMINISTRATEUR  </span>
              <span class="label label-theme pull-right mail-info"> <?= $free['nbre'] ;?> </span>
              </a>
          </li>         
          <li>
             <a href="../personnel/personnel.php">
              <i class="fa fa-dashboard"></i>
              <span>PERSONNEL</span>
              <span class="label label-theme pull-right mail-info"> <?= $freem['nbre'] ;?> </span>
              </a>
          </li>
          <li>
          <a href="../commentaire/commentaire.php">
           <i class="fa fa-dashboard"></i>
           <span>COMMENTAIRES</span>
           <span class="label label-theme pull-right mail-info"> <?= $freemanes['nbre'] ; ?> </span>
           </a>
        </li>
        <li>
             <a href="../immobilier/immobilier.php">
              <i class="fa fa-dashboard"></i>
              <span>IMMOBILIER</span>
              <span class="label label-theme pull-right mail-info"> <?= $freema['nbre']  ?> </span>
              </a>
          </li>
         

        </ul>
        <!-- sidebar menu end-->
      </div>
    </aside>