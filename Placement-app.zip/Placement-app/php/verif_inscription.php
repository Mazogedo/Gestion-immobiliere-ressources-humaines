<?php
require('php/bdd.php');
die;
if( !isset($_POST['name']) && !isset($_POST['pass']) && !isset($_POST['email']) && !isset($_POST['date']))

    {
        $hash = sha1($_POST['pass']);

        $req = $bdd ->prepare('INSERT INTO admin(pass,pseudo,birthday,email,hash) VALUES (?,?,?,?,?)');

        $test = $req ->execute(array($_POST['pass'],$_POST['name'],$_POST['date'],$_POST['email'],$hash))
 
        if ($test) 
            {
         echo '<script type="text/javascript"> alert("inscription reuissi") </script>';
            } 
        else
            {
        echo '<script type="text/javascript"> alert("inscription non reuissi") </script>';
            }
      

    }
else 
    {
   echo 'location:inscription.php';
    }




?>