<?php

	ob_start();

	date_default_timezone_set('Africa/Abidjan');

	if($_SESSION['statut']!=1)
	{
		echo "<script type='text/javascript'>location.href = '../index.php';</script>";
	}

	ob_end_flush();
	
?>