<?php
session_start();
include('../php/header.php');
include('../php/nav.php');
?>
<!--main content start-->
<section id="main-content">
      <section class="wrapper">
        <marquee style="font-size:30px;" >IMMOBILIER </marquee>
      </section>
      <div class="row mt">
          <div class="col-md-12">
            <div class="content-panel">
              <table border="1" class="table table-striped table-advance table-hover">
                <hr>
                <thead >
                  <tr bgcolor="silver">
                    <th><i class="fa fa-bookmark"></i> Commune</th>
                    <th class="hidden-phone"><i class="fa fa-question-circle"></i>details de la maison </th>
                    <th><i class="fa fa-bookmark"></i>prix de la maison </th>
                    <th><i class=" fa fa-edit"></i> nom de l'acquereur </th>
                    <th><i class="fa fa-bookmark"></i> choisir</th>
                  </tr>
                </thead>
                <?php
                include('../php/bdd.php');
                $date= date('Y-m-d');

                 //condition de teste
                  $solut=$bdd->prepare("SELECT *
                                        FROM immobilier");
                 $free = $solut->execute();

                $test = $solut-> fetchAll();

                foreach ($test as $cdcoll) :

                ?>
                <tr >
	 <td>
	<?= $cdcoll['commune'] ?> 
	 </td>	
	     <td>
	<?= $cdcoll['details'] ?>
         </td>
           <td>
	<?= $cdcoll['prix'] ?>
			</td>
			<td>
	<?= $cdcoll['nom_acquereur'] ?>
				</td>
		<td>
	<a onclick="fun()" href=" supprimer.php?id=<?= $cdcoll['immobilier_id'] ?>">Supprimer</a>
	<a onclick="full()" href="form_modifier.php?id=<?= $cdcoll['immobilier_id'] ?>">Modifier</a>
			</td>	
	</tr>
                
    <?php endforeach ?>
                 </tbody>
              </table>
            </div>
            <!-- /content-panel -->
          </div>
          <!-- /col-md-12 -->
        </div>
        <!-- /row -->
        <!-- /row -->
      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
    <script>
function fun() 
{
alert("voulez vous supprimer ?")	;
}
function full() 
{
alert("voulez vous modifier ?")	;
}

</script>

  <?php
  include('../php/footer.php');
  ?>  