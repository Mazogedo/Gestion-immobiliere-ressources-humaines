<?php

session_start();
include('../php/header.php');
include('../php/nav.php');
include('../php/bdd.php');

 $cand = $_GET['id'] ;

$req = $bdd ->prepare(' DELETE from immobilier where immobilier_id = ? ') ;

$free = $req ->execute(array($cand));

if ($free) {
    echo '<script> alert("donnees supprimes")</script>';
} else {
    echo '<script> alert("donnees non supprimes")</script>' ;
}


?>