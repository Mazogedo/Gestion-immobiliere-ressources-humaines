<?php

session_start();

include('../php/header.php');
include('../php/nav.php');
include('../php/bdd.php');

 

$req = $bdd ->prepare(' UPDATE immobilier set commune = ?,details = ?,prix = ?,nom_acquereur = ?  where immobilier_id = ? ') ;

$free = $req ->execute(array($_POST['commune'],$_POST['details'],$_POST['prix'],$_POST['nom'],$_SESSION['id']));

if ($free) {
    echo '<script> alert("donnees modifiees")</script>';
} else {
    echo '<script> alert("donnees non modifiees")</script>' ;
}


?>