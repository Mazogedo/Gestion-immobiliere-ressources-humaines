<?php

session_start();

include('../php/header.php');
include('../php/nav.php');
include('../php/bdd.php');

$hash = sha1($_POST['hash']);
 

$req = $bdd ->prepare(' UPDATE admin set pseudo= ?,birthday = ?,email = ?,hash = ? where id = ? ') ;

$free = $req ->execute(array($_POST['name'],$_POST['date'],$_POST['email'],$hash,$_SESSION['id']));

if ($free) {
    echo '<script> alert("donnees modifiees")</script>';
} else {
    echo '<script> alert("donnees non modifiees")</script>' ;
}


?>