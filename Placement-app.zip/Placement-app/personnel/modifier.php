<?php

session_start();

include('../php/header.php');
include('../php/nav.php');
include('../php/bdd.php');

$nom = $_POST['name'];
$prenom= $_POST['lastname'];
$metier = $_POST['metier'];
$nat = $_POST['nationalite'];
$sal = $_POST['salaire'];
$emp = $_POST['employeur'];



$req = $bdd ->prepare(' UPDATE personnel set nom_perso = ?,prenom_perso = ?,metier = ?,nationnalite= ?,salaire = ? ,nom_acquereur= ? where perso_id = ? ') ;

$free = $req ->execute(array( $nom,$prenom,$metier,$nat,$sal,$emp,$_SESSION['id']));

if ($free) {
    echo '<script> alert("donnees modifiees")</script>';
} else {
    echo '<script> alert("donnees non modifiees")</script>' ;
}


?>