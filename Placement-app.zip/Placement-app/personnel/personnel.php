<?php
session_start();
include('../php/header.php');
include('../php/nav.php');
?>
<!--main content start-->
<section id="main-content">
      <section class="wrapper">
        <marquee style="font-size:30px;" >PERSONNEL </marquee>
      </section>
      <div class="row mt">
          <div class="col-md-12">
            <div class="content-panel">
              <table border="1" class="table table-striped table-advance table-hover">
                <hr>
                <thead >
                  <tr bgcolor="silver">
                    <th><i class="fa fa-bookmark"></i> Nom_candidat</th>
                    <th class="hidden-phone"><i class="fa fa-question-circle"></i>prenom_candidat </th>
                    <th><i class="fa fa-bookmark"></i> Metier</th>
                    <th><i class=" fa fa-edit"></i> Nationnalite </th>
                    <th><i class="fa fa-bookmark"></i>Salaire </th>
                    <th><i class=" fa fa-edit"></i>Nom de l'employeur  </th>
                    <th><i class="fa fa-bookmark"></i> choisir</th>
                  </tr>
                </thead>
                <?php
                include('../php/bdd.php');
                $date= date('Y-m-d');

                 //condition de teste
                  $solut=$bdd->prepare("SELECT *
                                        FROM personnel");
                 $free = $solut->execute();

                $test = $solut-> fetchAll();

                foreach ($test as $cdcoll) :

                ?>
                <tr >
	 <td>
	<?= $cdcoll['nom_perso'] ?> 
	 </td>	
	     <td>
	<?= $cdcoll['prenom_perso'] ?>
         </td>
           <td>
	<?= $cdcoll['metier'] ?>
			</td>
			<td>
	<?= $cdcoll['nationnalite'] ?>
				</td>
			<td>
	<?= $cdcoll['salaire'] ?>
				</td>
				<td>
	<?= $cdcoll['nom_acquereur'] ?>
				</td>
		<td>
	<a onclick="fun()" href=" supprimer.php?id=<?= $cdcoll['perso_id'] ?>">Supprimer</a>
	<a onclick="full()" href="form_modifier.php?id=<?= $cdcoll['perso_id'] ?>">Modifier</a>
			</td>	
	</tr>
                
    <?php endforeach ?>
                 </tbody>
              </table>
            </div>
            <!-- /content-panel -->
          </div>
          <!-- /col-md-12 -->
        </div>
        <!-- /row -->
        <!-- /row -->
      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
    <script>
function fun() 
{
alert("voulez vous supprimer ?")	;
}
function full() 
{
alert("voulez vous modifier ?")	;
}

</script>

  <?php
  include('../php/footer.php');
  ?>  